using UnityEngine;

[System.Serializable]
public class PetData
{
    [Header("레벨 정보")]
    public int level = 1;
    public int currentExp = 0;
    public int maxExp = 100;
    
    [Header("펫 상태")]
    public float hunger = 100f;      // 배고픔 (0~100)
    public float friendship = 50f;   // 친밀도 (0~100)
    
    [Header("펫 정보")]
    public string petName = "나의 펫";
}
