using UnityEngine;
using UnityEngine.UI;
//using TMPro;
using System.Collections;
using System.Collections.Generic; // List 등을 사용하지 않아도 습관적으로 넣어주는 것이 좋습니다.

// FoodData가 별도 네임스페이스에 있지 않다면 필요 없습니다.
// using YourGame.FoodSystem; 

public class PetManager : MonoBehaviour
{
    public static PetManager Instance;
    
    [Header("펫 데이터")]
    public PetData petData = new PetData();
    
    [Header("상단 UI")]
    //public TextMeshProUGUI levelText;
    public Image expBar;
    //public TextMeshProUGUI expText;
    //public TextMeshProUGUI goldText;

    //->
    public Text levelText;
    public Text expText;
    public Text goldText;
    //<-

    [Header("펫 UI")]
    public Image hungerBar;
    public Image friendshipBar;
    public Image petImage;
    public Animator petAnimator;
    
    [Header("알림 UI")]
    public GameObject notificationPanel;
    //public TextMeshProUGUI notificationText;
    //->
    public Text notificationText;
    //<-
    
    [Header("먹이 선택 UI")] // 🌟 새로 추가됨
    public GameObject feedPanel; // 🍔 메뉴판 전체 오브젝트
    // Feed Main Button은 Inspector에서 ToggleFeedPanel() 함수에 연결해줍니다.

    [Header("골드")]
    public int playerGold = 1000;
    
    [Header("설정")]
    public float hungerDecreaseRate = 1f;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            // 씬 이동 시 파괴 방지 (선택 사항, 필요시 주석 해제)
            // DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void Start()
    {
        LoadPetData();
        UpdateUI();
        InvokeRepeating("DecreaseHunger", 1f, 60f);
        
        // 알림창 처음에 숨기기
        if (notificationPanel != null)
        {
            notificationPanel.SetActive(false);
        }
        
        // 🌟 메뉴판 처음에 숨기기
        if (feedPanel != null)
        {
            feedPanel.SetActive(false);
        }
    }
    
    // UI 업데이트 (기존 로직 유지)
    void UpdateUI()
    {
        if (levelText != null)
        {
            levelText.text = "Lv. " + petData.level;
        }
        
        if (expBar != null)
        {
            expBar.fillAmount = (float)petData.currentExp / petData.maxExp;
        }
        
        if (expText != null)
        {
            expText.text = petData.currentExp + "/" + petData.maxExp;
        }
        
        if (goldText != null)
        {
            goldText.text = playerGold.ToString();
        }
        
        if (hungerBar != null)
        {
            hungerBar.fillAmount = petData.hunger / 100f;
        }
        
        if (friendshipBar != null)
        {
            friendshipBar.fillAmount = petData.friendship / 100f;
        }
    }
    
    // 🌟 1. '먹이주기' 버튼 클릭 시 호출 (메뉴판 토글 기능)
    // 기존의 FeedPet() 함수를 대체합니다.
    public void ToggleFeedPanel()
    {
        if (feedPanel == null) return;
        
        // 현재 상태를 반전시켜 메뉴판을 열고 닫습니다.
        feedPanel.SetActive(!feedPanel.activeSelf);
        
        // (메뉴판 애니메이션 로직 추가 위치)
    }

    // 🌟 2. 요리 버튼이 호출하는 최종 처리 함수
    public void ProcessFoodSelection(FoodData food)
    {
        // 1. 배고픔 확인
        if (petData.hunger >= 100f)
        {
            ShowNotification("배가 고프지 않아요!");
            ToggleFeedPanel(); // 메뉴판 닫기
            return;
        }
        
        // 2. 골드 확인 및 차감
        if (playerGold < food.price)
        {
            ShowNotification("골드가 부족해요! (" + food.price + " Gold)");
            return;
        }
        
        // 3. 처리 (골드 차감, 상태 변화)
        playerGold -= food.price; 
        petData.hunger = Mathf.Min(100f, petData.hunger + food.hungerRecovery); // FoodData의 값 사용
        
        // 4. 경험치 부여 (FoodData의 값 사용)
        AddExp(food.expGain);
        
        // 5. 애니메이션 및 알림
        if (petAnimator != null)
        {
            petAnimator.SetTrigger("Eat");
        }
        UpdateUI();
        SavePetData();
        ShowNotification(food.foodName + "을(를) 맛있게 먹었어요! (+EXP " + food.expGain + ")");
        
        // 6. 메뉴판 닫기
        ToggleFeedPanel();
    }
    
    // 쓰다듬기 (기존 로직 유지)
    public void PatPet()
    {
        if (petAnimator != null)
        {
            petAnimator.SetTrigger("Happy");
        }
        
        petData.friendship = Mathf.Min(100f, petData.friendship + 5f);
        AddExp(5);
        UpdateUI();
        SavePetData();
        
        ShowNotification("기분이 좋아요!");
    }
    
    // 놀아주기 (기존 로직 유지)
    public void PlayWithPet()
    {
        if (petData.hunger < 30f)
        {
            ShowNotification("배가 고파서 놀 수 없어요!");
            return;
        }
        
        petData.friendship = Mathf.Min(100f, petData.friendship + 15f);
        petData.hunger = Mathf.Max(0f, petData.hunger - 20f);
        AddExp(20);
        UpdateUI();
        SavePetData();
        
        ShowNotification("함께 놀았어요!");
    }
    
    // 알림 표시 및 숨기기 (기존 로직 유지)
    void ShowNotification(string message)
    {
        if (notificationPanel != null && notificationText != null)
        {
            notificationText.text = message;
            notificationPanel.SetActive(true);
            StartCoroutine(HideNotificationAfterDelay(2f));
        }
    }
    
    IEnumerator HideNotificationAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (notificationPanel != null)
        {
            notificationPanel.SetActive(false);
        }
    }
    
    // 경험치 추가 (기존 로직 유지)
    void AddExp(int amount)
    {
        petData.currentExp += amount;
        
        while (petData.currentExp >= petData.maxExp)
        {
            LevelUp();
        }
    }
    
    // 레벨업 (기존 로직 유지)
    void LevelUp()
    {
        petData.level++;
        petData.currentExp -= petData.maxExp;
        petData.maxExp = Mathf.RoundToInt(petData.maxExp * 1.5f);
        
        ShowNotification("레벨 업! Lv." + petData.level );
    }
    
    // 배고픔 감소 (기존 로직 유지)
    void DecreaseHunger()
    {
        petData.hunger = Mathf.Max(0f, petData.hunger - hungerDecreaseRate);
        UpdateUI();
        SavePetData();
    }
    
    // 데이터 저장/불러오기 (기존 로직 유지)
    void SavePetData()
    {
        PlayerPrefs.SetInt("PetLevel", petData.level);
        PlayerPrefs.SetInt("PetExp", petData.currentExp);
        PlayerPrefs.SetInt("PetMaxExp", petData.maxExp);
        PlayerPrefs.SetFloat("PetHunger", petData.hunger);
        PlayerPrefs.SetFloat("PetFriendship", petData.friendship);
        PlayerPrefs.SetInt("PlayerGold", playerGold);
        PlayerPrefs.Save();
    }
    
    void LoadPetData()
    {
        petData.level = PlayerPrefs.GetInt("PetLevel", 1);
        petData.currentExp = PlayerPrefs.GetInt("PetExp", 0);
        petData.maxExp = PlayerPrefs.GetInt("PetMaxExp", 100);
        petData.hunger = PlayerPrefs.GetFloat("PetHunger", 100f);
        petData.friendship = PlayerPrefs.GetFloat("PetFriendship", 50f);
        playerGold = PlayerPrefs.GetInt("PlayerGold", 1000);
    }
}