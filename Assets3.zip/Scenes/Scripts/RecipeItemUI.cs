using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RecipeItemUI : MonoBehaviour
{
    [Header("������ ����")]
    public string recipeName;
    public string ingredientList;
    public string recipeDesc;
    public string recipeEfficacy;
    public string foodId;

    [Header("ȹ�� ����ġ")]
    public int expValue;

    [Header("InfoBox UI")]
    public TextMeshProUGUI recipeNameText;
    public TextMeshProUGUI ingredientListText;
    public TextMeshProUGUI recipeDescText;
    public TextMeshProUGUI recipeEfficacyText;
    public TextMeshProUGUI expText;
    public Button cookButton;

    [Header("��� ���� �޽���")]
    public TextMeshProUGUI notEnoughText;

    private SceneLoader sceneLoader;

    void Start()
    {
        sceneLoader = FindObjectOfType<SceneLoader>();

        cookButton.onClick.RemoveAllListeners();
        cookButton.onClick.AddListener(OnClickCook);

        //notEnoughText.gameObject.SetActive(false);
    }

    // ������ ������ Ŭ��
    public void OnClick()
    {
        recipeNameText.text = recipeName;
        ingredientListText.text = ingredientList;
        recipeDescText.text = recipeDesc;
        recipeEfficacyText.text = recipeEfficacy;
        expText.text = "+ " + expValue + " Exp";

        GameData.selectedFood = foodId;
        GameData.selectedRecipeName = recipeName;
        GameData.selectedDesc = recipeDesc;
        GameData.selectedEfficacy = recipeEfficacy;
        GameData.selectedExp = expValue;
    }

    // ���� ���� ��ư Ŭ��
    public void OnClickCook()
    {
        Debug.Log("���� ��ư Ŭ����");

        if (string.IsNullOrEmpty(GameData.selectedFood))
        {
            Debug.LogWarning("���õ� �丮�� �����ϴ�.");
            return;
        }

        if (!InventoryData.CanCook(GameData.selectedFood))
        {
            StartCoroutine(ShowNotEnough());
            return;
        }

        // ��� ����
        InventoryData.ConsumeForCooking(GameData.selectedFood);

        // Cooking �� �̵�
        sceneLoader.SelectFoodAndCook(GameData.selectedFood);
    }

    IEnumerator ShowNotEnough()
    {
        notEnoughText.gameObject.SetActive(true);
        yield return new WaitForSeconds(2f);
        notEnoughText.gameObject.SetActive(false);
    }
}
