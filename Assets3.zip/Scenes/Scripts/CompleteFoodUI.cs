using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CompleteFoodInfoUI : MonoBehaviour
{
    [Header("�ϼ� ���� �̹���")]
    public Image completeFoodImage;

    [Header("�ؽ�Ʈ UI")]
    public TextMeshProUGUI recipeNameText;
    public TextMeshProUGUI efficacyText;
    public TextMeshProUGUI expText;

    [Header("���� ��������Ʈ")]
    public Sprite sushiSprite;
    public Sprite gimbapSprite;
    public Sprite steakSprite;
    public Sprite eggPickleSprite;
    public Sprite lemonPieSprite;

    void Start()
    {
        recipeNameText.text = GameData.selectedRecipeName;
        efficacyText.text = GameData.selectedEfficacy;
        expText.text = "+ " + GameData.selectedExp + " Exp";

        // ���� �̹��� ����
        switch (GameData.selectedFood)
        {
            case "sushi": completeFoodImage.sprite = sushiSprite; break;
            case "gimbap": completeFoodImage.sprite = gimbapSprite; break;
            case "steak": completeFoodImage.sprite = steakSprite; break;
            case "eggPickle": completeFoodImage.sprite = eggPickleSprite; break;
            case "lemonPie": completeFoodImage.sprite = lemonPieSprite; break;
        }

        // �ϼ� ���� �κ��丮�� �߰�
        InventoryData.Instance.AddFood(GameData.selectedFood);
    }
}
