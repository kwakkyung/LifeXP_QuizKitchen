using UnityEngine;

public class CookingTimer : MonoBehaviour
{
    private void Start()
    {
        // 7�� �� Complete ������ �̵�
        Invoke(nameof(GoComplete), 7f);
    }

    void GoComplete()
    {
        SceneLoader loader = FindObjectOfType<SceneLoader>();

        if (loader != null)
        {
            loader.LoadCompleteScene();  
        }
        else
        {
            Debug.LogError("SceneLoader�� ã�� �� �����ϴ�.");
        }
    }
}
