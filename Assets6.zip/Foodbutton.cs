using UnityEngine;
using UnityEngine.UI;
//using TMPro; // TMP를 사용하므로 추가

public class FoodButton : MonoBehaviour
{
    // ⚠️ Inspector에서 FoodData 파일을 연결해야 합니다.
    [Header("연결할 음식 데이터")]
    public FoodData foodData;

    // UI 표시용 (옵션)
    //public TextMeshProUGUI nameText;
    //->
    public Text nameText;
    //<-
    public Image iconImage;

    void Start()
    {
        Button button = GetComponent<Button>();
        
        // 버튼 클릭 이벤트 연결
        if (button != null)
        {
            // 클릭 시 ProcessFoodSelection 함수를 호출하도록 설정
            button.onClick.AddListener(OnFoodSelected);
        }

        // UI 표시 (옵션)
        if (foodData != null && nameText != null)
        {
            nameText.text = foodData.foodName + " (" + foodData.price + "G)";
            if (iconImage != null && foodData.foodIcon != null)
            {
                iconImage.sprite = foodData.foodIcon;
            }
        }
    }

    void OnFoodSelected()
    {
        if (foodData != null && PetManager.Instance != null)
        {
            // 🌟 PetManager의 최종 처리 함수를 호출하며 FoodData를 전달합니다.
            PetManager.Instance.ProcessFoodSelection(foodData);
        }
        else if (PetManager.Instance == null)
        {
            Debug.LogError("PetManager.Instance를 찾을 수 없습니다.");
        }
    }
}