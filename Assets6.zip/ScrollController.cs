using UnityEngine;

public class ScrollController : MonoBehaviour
{
    // Inspector에 노출되는 변수
    [Header("스크롤 설정")]
    public RectTransform itemContainer; // 스크립트가 붙은 오브젝트 자신 (Awake에서 자동 연결 시도)
    public float itemWidth = 1080f;    // 페이지 1칸 너비 (360 * 3)
    public float moveSpeed = 8f;       // 부드러운 이동 속도

    // 스크립트 내부에서 사용되는 변수
    private Vector2 targetPosition;
    private int currentIndex = 0; // 현재 스크롤 위치 인덱스 (0, 3, 6, ...)
    private int totalItems;      // 컨테이너 내부의 총 아이템 개수

    void Awake()
    {
        // 1. 스크립트가 붙은 오브젝트의 RectTransform을 가져옵니다.
        itemContainer = GetComponent<RectTransform>(); 
        
        // 2. 총 아이템 개수를 세어 이동 가능 여부를 판단합니다.
        totalItems = itemContainer.childCount;
        
        // 3. 초기 목표 위치를 현재 위치로 설정합니다.
        targetPosition = itemContainer.anchoredPosition; 
    }

    void Update()
    {
        // 🌟 1. 이 코드가 없으면 절대 움직이지 않습니다.
        // 목표 위치 targetPosition을 향해 부드럽게 이동합니다.
        itemContainer.anchoredPosition = Vector2.Lerp(
            itemContainer.anchoredPosition, 
            targetPosition, 
            Time.deltaTime * moveSpeed
        );
    }

    // --- A. 좌우 이동 함수 (각 버튼에 연결) ---
    public void MoveNext()
    {
        // 🌟 2. 이동 조건: 현재 인덱스(currentIndex) + 3 이 총 아이템 개수(totalItems)보다 작아야 이동 가능.
        // 예를 들어, totalItems가 3개라면 (0 + 3 < 3)은 거짓이 되어 이동하지 않습니다.
        if (currentIndex + 3 < totalItems) 
        {
            currentIndex += 3;
            CalculateTargetPosition();
        } 
        else
        {
            // 이동할 수 없는 경우 디버그 메시지 출력
            Debug.Log("MoveNext 불가: 현재 인덱스 " + currentIndex + ", 총 아이템 개수 " + totalItems);
        }
    }

    public void MovePrevious()
    {
        // 뒤로 갈 곳이 있을 때만 이동
        if (currentIndex > 0)
        {
            currentIndex -= 3;
            if (currentIndex < 0) { currentIndex = 0; }
            CalculateTargetPosition();
        }
    }

    void CalculateTargetPosition()
    {
        // 아이템 1개 너비 = ItemWidth / 3 = 360
        float singleItemWidth = itemWidth / 3;
        
        // 목표 X 위치 = - (현재 인덱스) * (아이템 1개 너비)
        float targetX = -currentIndex * singleItemWidth; 
        
        // 목표 위치 업데이트 (Y는 유지)
        targetPosition = new Vector2(targetX, itemContainer.anchoredPosition.y); 
    }
}





/*using UnityEngine;

public class ScrollController : MonoBehaviour
{
    public RectTransform content;  
    public float itemWidth = 100f;
    public int itemsPerPage = 3;
    public float moveSpeed = 8f;

    private Vector2 targetPos;
    private int currentIndex = 0;
    private int totalItems;

    void Start()
    {
        totalItems = content.childCount;
        targetPos = content.anchoredPosition;
    }

    void Update()
    {
        content.anchoredPosition =
            Vector2.Lerp(content.anchoredPosition, targetPos, Time.deltaTime * moveSpeed);
    }

    public void NextPage()
    {
        if (currentIndex + itemsPerPage < totalItems)
        {
            currentIndex += itemsPerPage;
            Calculate();
        }
    }

    public void PrevPage()
    {
        if (currentIndex - itemsPerPage >= 0)
        {
            currentIndex -= itemsPerPage;
            Calculate();
        }
    }

    void Calculate()
    {
        targetPos = new Vector2(-currentIndex * itemWidth, content.anchoredPosition.y);
    }
}

/*using UnityEngine;

public class ScrollController : MonoBehaviour
{
    [Header("스크롤 설정")]
    // 이 변수는 Awake에서 자동으로 이 오브젝트의 RectTransform을 가져오게 했습니다.
    public RectTransform itemContainer; 
    public float itemWidth = 1080f;    // 페이지당 이동할 너비 (3개 묶음 너비)
    public float moveSpeed = 8f;

    private Vector2 targetPosition;
    private int currentIndex = 0;
    private int totalItems;

    void Awake()
    {
        // 이 스크립트가 부착된 오브젝트의 RectTransform을 가져옵니다.
        itemContainer = GetComponent<RectTransform>(); 
        totalItems = itemContainer.childCount;
        targetPosition = itemContainer.anchoredPosition;
    }

    void Update()
    {
        // 🌟 이 컨테이너만 부드럽게 목표 위치로 이동
        itemContainer.anchoredPosition = Vector2.Lerp(
            itemContainer.anchoredPosition, 
            targetPosition, 
            Time.deltaTime * moveSpeed
        );
    }

    // --- A. 좌우 이동 함수 (각 버튼에 연결) ---
    public void MoveNext()
    {
        if (currentIndex + 3 < totalItems) 
        {
            currentIndex += 3;
            CalculateTargetPosition();
        }
    }

    public void MovePrevious()
    {
        if (currentIndex > 0)
        {
            currentIndex -= 3;
            if (currentIndex < 0) { currentIndex = 0; }
            CalculateTargetPosition();
        }
    }

    void CalculateTargetPosition()
    {
        // 아이템 하나의 너비 (360)를 곱하여 최종 X 위치를 계산합니다.
        float targetX = -currentIndex * (itemWidth / 3); 
        targetPosition = new Vector2(targetX, itemContainer.anchoredPosition.y); 
    }
}*/