using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ShopManager : MonoBehaviour
{
    // 싱글톤
    public static ShopManager Instance;

    [Header("상세 정보 UI 연결")]
    public GameObject detailPanel;          // ItemDetailPanel
    public Image detailIcon;                // 아이템 아이콘
    public Text detailName;                 // 아이템 이름
    public Text detailDescription;          // 아이템 설명
    public Text detailPrice;                // 아이템 가격
    public Button purchaseButton;           // 구매 버튼
    
    [Header("알림 UI")]
    public GameObject purchaseNotification; // 구매 알림 패널
    public Text notificationText;           // 알림 텍스트
    
    // 현재 선택된 아이템
    private ItemData selectedItem;

    void Awake()
    {
        // 싱글톤 설정
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
        
        // 상세 패널 처음엔 숨기기
        if (detailPanel != null)
        {
            detailPanel.SetActive(false);
        }
        
        // 알림창도 처음에 숨기기
        if (purchaseNotification != null)
        {
            purchaseNotification.SetActive(false);
        }
        
        // 구매 버튼 이벤트 연결
        if (purchaseButton != null)
        {
            purchaseButton.onClick.RemoveAllListeners();
            purchaseButton.onClick.AddListener(OnPurchaseButtonClicked);
        }
    }
    
    // 상세 정보 패널 열기
    public void OpenDetailPanel(ItemData data)
    {
        // 데이터 유효성 검사
        if (data == null)
        {
            Debug.LogError("ItemData가 null입니다!");
            return;
        }
        
        // 디버그 출력
        Debug.Log("상세 정보 열기: " + data.itemName);
        
        // 현재 아이템 저장
        selectedItem = data;
        
        // UI 초기화 (이전 데이터 제거)
        if (detailName != null) detailName.text = "";
        if (detailDescription != null) detailDescription.text = "";
        if (detailPrice != null) detailPrice.text = "";
        
        // 아이콘 업데이트
        if (detailIcon != null && data.itemIcon != null)
        {
            detailIcon.sprite = data.itemIcon;
            detailIcon.enabled = true;
        }
        else if (detailIcon != null)
        {
            detailIcon.enabled = false; // 아이콘 없으면 숨기기
        }
        
        // 텍스트 업데이트
        if (detailName != null)
        {
            detailName.text = data.itemName;
        }
        
        if (detailDescription != null)
        {
            detailDescription.text = data.itemDescription;
        }
        
        if (detailPrice != null)
        {
            detailPrice.text = data.price.ToString() + " Gold";
        }
        
        // 디버그 출력
        Debug.Log("UI 업데이트 완료: " + detailName.text);
        
        // 패널 표시
        if (detailPanel != null)
        {
            detailPanel.SetActive(true);
        }
    }
    
    // 구매 버튼 클릭
    public void OnPurchaseButtonClicked()
    {
        if (selectedItem == null)
        {
            Debug.LogError("선택된 아이템이 없습니다!");
            return;
        }
        
        Debug.Log(selectedItem.itemName + " 구매 시도");
        
        // TODO: 골드 확인 로직
        // int playerGold = GameManager.Instance.GetGold();
        // if (playerGold < selectedItem.price)
        // {
        //     ShowPurchaseNotification("골드가 부족합니다!");
        //     return;
        // }
        
        // 인벤토리에 아이템 추가
        if (InventoryManager.Instance != null)
        {
            InventoryManager.Instance.AddItem(selectedItem);
            
            // TODO: 골드 차감
            // GameManager.Instance.SpendGold(selectedItem.price);
            
            // 구매 완료 알림
            ShowPurchaseNotification("구매가 완료되었습니다!");
            
            // 상세 패널 닫기
            CloseDetailPanel();
        }
        else
        {
            Debug.LogError("InventoryManager를 찾을 수 없습니다!");
        }
    }
    
    // 상세 패널 닫기
    public void CloseDetailPanel()
    {
        if (detailPanel != null)
        {
            detailPanel.SetActive(false);
        }
        
        selectedItem = null;
    }
    
    // 구매 알림 표시
    public void ShowPurchaseNotification(string message)
    {
        if (purchaseNotification != null && notificationText != null)
        {
            notificationText.text = message;
            purchaseNotification.SetActive(true);
            
            // 2초 후 자동으로 숨기기
            StartCoroutine(HideNotificationAfterDelay(2f));
        }
    }
    
    // 일정 시간 후 알림 숨기기
    IEnumerator HideNotificationAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        
        if (purchaseNotification != null)
        {
            purchaseNotification.SetActive(false);
        }
    }
}
