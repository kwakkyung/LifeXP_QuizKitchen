using UnityEngine;
using System.Collections.Generic;

public class InventoryManager : MonoBehaviour
{
    // 씬 전체에서 한 번에 접근 가능하도록 'Instance'를 만듭니다.
    public static InventoryManager Instance;
    
    private List<ItemData> inventory = new List<ItemData>(); // 아이템을 보관할 리스트

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    // ShopManager가 아이템 구매 후 호출하는 함수
    public void AddItem(ItemData item)
    {
        inventory.Add(item);
        Debug.Log("인벤토리에 " + item.itemName + "을(를) 성공적으로 추가했습니다! (총 " + inventory.Count + "개)");
        // 여기에 인벤토리 UI 업데이트 코드를 넣습니다.
    }
}

