using UnityEngine;

// Project 창에서 우클릭으로 음식 데이터 파일 생성 가능
[CreateAssetMenu(fileName = "New Food", menuName = "Pet/Food Data")]
public class FoodData : ScriptableObject
{
    [Header("음식 정보")]
    public string foodName = "일반 사료";
    public Sprite foodIcon;
    public int expGain = 10;        // 획득 경험치 양
    public float hungerRecovery = 30f; // 회복되는 배고픔 수치
    public int price = 50;          // 소모되는 골드
}