using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class ShopItemButton : MonoBehaviour, IPointerClickHandler
{
    // --- 1. Inspector에서 연결할 변수 ---
    [Header("데이터 연결 (필수)")]
    // 이 슬롯에 ItemData ScriptableObject 파일을 드래그하여 연결합니다.
    public ItemData itemData; 
    
    [Header("UI 표시용 연결")]
    // 아이템 슬롯의 자식 오브젝트에 있는 Image와 Text 컴포넌트를 연결합니다.
    public Image iconImage;
    public Text nameText;
    

    void Start()
    {
        // 씬이 시작될 때, 연결된 데이터에 따라 슬롯 UI를 초기화합니다.
        if (itemData != null)
        {
            if (iconImage != null && itemData.itemIcon != null)
            {
                // ItemData에 저장된 아이콘 이미지로 변경
                iconImage.sprite = itemData.itemIcon; 
            }
            if (nameText != null)
            {
                // ItemData에 저장된 이름으로 변경
                nameText.text = itemData.itemName; 
            }
        }
    }

    // --- 2. 클릭 이벤트 처리 함수 ---
    // 마우스로 이 오브젝트를 클릭했을 때 자동으로 실행됩니다.
    public void OnPointerClick(PointerEventData eventData)
    {
        // 연결된 데이터가 없으면 오류 메시지를 띄우고 종료
        if (itemData == null)
        {
            Debug.LogError(gameObject.name + ": ItemData가 연결되지 않아 상세 정보를 열 수 없습니다!");
            return;
        }
        
        // ShopManager의 싱글톤 인스턴스에 접근하여 OpenDetailPanel 함수 호출
        if (ShopManager.Instance != null)
        {
            // 이 버튼이 가진 ItemData를 ShopManager로 전달합니다.
            ShopManager.Instance.OpenDetailPanel(itemData);
        }
        else
        {
            Debug.LogError("ShopManager.Instance를 찾을 수 없습니다. ShopManager 오브젝트를 확인하세요.");
        }
    }
}