/*using UnityEngine;
using UnityEngine.SceneManagement;

public class BackButtonManager : MonoBehaviour
{
    public GameObject menuPanel;
    public GameObject accountPanel;
    public GameObject soundPanel;
    public GameObject infoPanel;

    public string quizSceneName = "QuizScene";

    public void OnBackPressed()
    {
        if (accountPanel.activeSelf || soundPanel.activeSelf || infoPanel.activeSelf)
        {
            CloseAllSubPanels();
            menuPanel.SetActive(true);
        }

        else if (menuPanel.activeSelf)
        {
            SceneManager.LoadScene(quizSceneName);
        }
    }

    private void CloseAllSubPanels()
    {
        accountPanel.SetActive(false);
        soundPanel.SetActive(false);
        infoPanel.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            OnBackPressed();
        }
    }
    /*public void GoBackToMain()
    {
        SceneManager.LoadScene("QuizScene");
    }
}*/
