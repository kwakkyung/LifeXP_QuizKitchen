//using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public Text coinText;

    [Header("Panels")]
    public GameObject categoryPanel;
    public GameObject quizPanel;
    public GameObject resultPanel;

    [Header("Quiz UI")]
    public Text questionText;
    public Text progressText;
    public Image[] lifeImages;
    public Text resultText;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        ShowCategoryPanel();
    }

    public void DisplayQuestion(Question q, int currentIndex, int totalQuestions)
    {
        questionText.text = q.questionText;
        progressText.text = $"{currentIndex} / {totalQuestions}";
    }

    public void UpdateLives(int currentLives)
    {
        for (int i = 0; i < lifeImages.Length; i++)
        {
            lifeImages[i].enabled = i < currentLives;
        }
    }

    public void SetResult(int score, int coins, bool isGameClear)//int correct, int total)
    {
        if (isGameClear)
        {
            resultText.text = $"���� Ŭ����!\n����: {score}";
        }
        else
        {
            resultText.text = $"���� ����!\n����: {score}";
        }
        if (coinText != null)
        {
            coinText.text = $"ȹ�� ���� : {coins}";
        }
    }

    public void ShowCategoryPanel()
    {
        categoryPanel.SetActive(true);
        quizPanel.SetActive(false);
        resultPanel.SetActive(false);
    }

    public void ShowQuizPanel()
    {
        categoryPanel.SetActive(false);
        quizPanel.SetActive(true);
        resultPanel.SetActive(false);
    }

    public void ShowResultPanel()
    {
        categoryPanel.SetActive(false);
        quizPanel.SetActive(false);
        resultPanel.SetActive(true);
    }
}
