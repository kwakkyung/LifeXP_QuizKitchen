using UnityEngine;

public class CategorySelector : MonoBehaviour
{
    public QuestionDatabase database;
    public QuizManager quizManager;

    public void OnCategorySelected()
    {
        quizManager.SetCategory(database);
        quizManager.StartQuiz();
    }
}
