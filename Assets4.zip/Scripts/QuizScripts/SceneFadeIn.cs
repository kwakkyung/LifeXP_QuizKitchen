using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class SceneFadeIn : MonoBehaviour
{
    public Image fadeBlack;
    public float fadeDuration = 1f;

    public AudioSource quizBgmAudioSource;
    public float targetVolume = 1f;

    private void Awake()
    {
        if (fadeBlack != null)
        {
            Color c = fadeBlack.color;
            c.a = 1f;
            fadeBlack.color = c;

            fadeBlack.raycastTarget = true;
        }
        
        if (quizBgmAudioSource != null)
        {
            quizBgmAudioSource.volume = 0f;
            if (!quizBgmAudioSource.isPlaying)
            {
                quizBgmAudioSource.Play();
            }
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (fadeBlack != null)
        {
            StartCoroutine(FadeIn());
        }
    }

    private IEnumerator FadeIn()
    {
        Color c = fadeBlack.color;
        float t = 0f;

        while (t < fadeDuration)
        {
            t += Time.unscaledDeltaTime;
            float normalized = Mathf.Clamp01(t / fadeDuration);

            float alpha = 1f - normalized;
            fadeBlack.color = new Color(c.r, c.g, c.b, alpha);

            if (quizBgmAudioSource != null)
            {
                quizBgmAudioSource.volume = Mathf.Lerp(0f, targetVolume, normalized);
            }
            yield return null;
        }

        fadeBlack.raycastTarget = false;
        fadeBlack.gameObject.SetActive(false);
    }
}
