using System.Collections.Generic;
//using TMPro;
using UnityEngine;


public class QuizManager : MonoBehaviour
{
    //public int numberOfQuestionsToPick = 5;
    public int maxLives = 3;
    public int coinPerCorrect = 50;

    private QuestionDatabase currentDatabase;
    private List<Question> selectedQuestions = new List<Question>();
    private int currentIndex = 0;
    private int score = 0;
    private int lives;
    private int coins;

    private UIManager ui;

    private void Awake()
    {
        ui = FindObjectOfType<UIManager>();
    }

    public void SetCategory(QuestionDatabase database)
    {
        currentDatabase = database;
    }
    public void StartQuiz()
    {
        if (currentDatabase == null)
        {
            Debug.LogError("ī�װ��� �̼���");
            return;
        }

        currentIndex = 0;
        score = 0;
        lives = maxLives;

        ui.UpdateLives(lives);

        PickRandomQuestions();
        ui.ShowQuizPanel();
        ShowNextQuestion();
    }

    private void PickRandomQuestions()
    {
        selectedQuestions.Clear();
        List<Question> temp = new List<Question>(currentDatabase.questions);

        for (int i = 0; i < 10 && temp.Count > 0; i++)
        {
            int rand = Random.Range(0, temp.Count);
            selectedQuestions.Add(temp[rand]);
            temp.RemoveAt(rand);
        }
    }

    private void ShowNextQuestion()
    {
        if(currentIndex >= selectedQuestions.Count)
        {
            FinishQuiz();
            return;
        }

        ui.DisplayQuestion(selectedQuestions[currentIndex], currentIndex + 1, selectedQuestions.Count);
    }

    public void OnAnswerSelected(bool userAnswer)
    {
        if (selectedQuestions[currentIndex].answer != userAnswer)
        {
            lives--;
            ui.UpdateLives(lives);
            if (lives <= 0)
            {
                FinishQuiz();
                return;
            }
        }
        else
        {
            score++;
            coins += coinPerCorrect;
        }

        currentIndex++;
        ShowNextQuestion();
    }

    private void FinishQuiz()
    {
        bool isGameClear = lives > 0;
        ui.SetResult(score, coins, isGameClear); //selectedQuestions.Count);
        ui.ShowResultPanel();
    }
}
