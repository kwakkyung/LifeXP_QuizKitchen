using UnityEngine;
using UnityEngine.SceneManagement;

public class BGMManager : MonoBehaviour
{
    public static BGMManager Instance;

    public AudioSource audioSource;

    public AudioClip startBGM;
    public AudioClip quizBGM;
    //public AudioClip cookingBGM;
    //public AudioClip petBGM;
    //public AudioClip storeBGM;
    public AudioClip settingsBGM;
    //public AudioClip ;

    bool isMute = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (audioSource == null)
        {
            audioSource = GetComponent<AudioSource>();
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        ChangeBGM(scene.name);
    }

    void ChangeBGM(string sceneName)
    {
        AudioClip nextClip = null;

        switch (sceneName)
        {
            case "StartScene" :
                nextClip = startBGM;
                break;
            case "QuizScene" :
                nextClip = quizBGM;
                break;
            case "SettingsScene" :
                nextClip = settingsBGM;
                break;
        }

        if (nextClip != null && audioSource.clip != nextClip)
        {
            audioSource.clip = nextClip;

            if (!isMute)
            {
                audioSource.Play();
            }
        }
    }

    public void ToggleBGM()
    {
        isMute = !isMute;
        audioSource.mute = isMute;
    }

    public bool IsMute()
    {
        return isMute;
    }
}
