using UnityEngine;

public class BGMController : MonoBehaviour
{
    AudioSource bgm;
    bool isMute = false;

    private void Awake()
    {
        bgm = GetComponent<AudioSource>();
    }

    public void ToggleBGM()
    {
        isMute = !isMute;
        bgm.mute = isMute;
    }
}
