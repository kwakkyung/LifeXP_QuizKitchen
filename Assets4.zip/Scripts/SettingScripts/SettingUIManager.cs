using UnityEngine;

public class SettingUIManager : MonoBehaviour
{
    public GameObject menuPanel;
    public GameObject accountPanel;
    public GameObject soundPanel;
    public GameObject infoPanel;

    public void ShowMenu()
    {
        menuPanel.SetActive(true);
        accountPanel.SetActive(false);
        soundPanel.SetActive(false);
        infoPanel.SetActive(false);

    }
    public void ShowAccount()
    {
        menuPanel.SetActive(false);
        accountPanel.SetActive(true);
        soundPanel.SetActive(false);
        infoPanel.SetActive(false);
    }
    public void ShowSound()
    {
        menuPanel.SetActive(false);
        accountPanel.SetActive(false);
        soundPanel.SetActive(true);
        infoPanel.SetActive(false);
    }
    public void ShowInfo()
    {
        menuPanel.SetActive(false);
        accountPanel.SetActive(false);
        soundPanel.SetActive(false);
        infoPanel.SetActive(true);
    }
}
