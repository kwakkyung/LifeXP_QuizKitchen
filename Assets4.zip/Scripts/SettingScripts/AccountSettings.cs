using UnityEngine;
using UnityEngine.UI;

public class AccountSettings : MonoBehaviour
{
    [SerializeField] private InputField nicknameInput;
    [SerializeField] private Text nicknameText;

    private const string NicknameKey = "PlayerNickname";
    private string currentNickname = "����";

    private void Start()
    {
        if (PlayerPrefs.HasKey(NicknameKey))
        {
            currentNickname = PlayerPrefs.GetString(NicknameKey);
        }

        nicknameInput.text = currentNickname;
        nicknameText.text = currentNickname;
    }

    public void OnClickChangeNickname()
    {
        string newName = nicknameInput.text.Trim();

        if (string.IsNullOrEmpty(newName))
        {
            newName = "����";
            nicknameInput.text = newName;
        }

        currentNickname = newName;

        PlayerPrefs.SetString(NicknameKey, currentNickname);
        PlayerPrefs.Save();

        nicknameText.text = currentNickname; //"�г��� : " + currentNickname;
    }

    public string GetCurrentNickname()
    {
        return currentNickname;
    }
    /*public InputField nicknameInput;
    public Text currentNicknameText;

    public void ChangeNickname()
    {
        string newName = nicknameInput.text;
        if (!string.IsNullOrEmpty(newName))
        {
            currentNicknameText.text = newName;
            PlayerPrefs.SetString("Nickname", newName);
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        currentNicknameText.text = PlayerPrefs.GetString("Nickname", "Guest");
    }

    // Update is called once per frame
    void Update()
    {
        
    }*/
}
