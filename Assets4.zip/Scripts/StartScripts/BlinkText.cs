using UnityEngine;
using UnityEngine.UI;

public class BlinkText : MonoBehaviour
{
    public Text uiText;
    public float blinkSpeed = 3f;

    // Update is called once per frame
    void Update()
    {
        if (uiText != null)
        {
            float alpha = Mathf.Abs(Mathf.Sin(Time.time * blinkSpeed));
            Color c = uiText.color;
            c.a = alpha;
            uiText.color = c;
        }
    }
}
