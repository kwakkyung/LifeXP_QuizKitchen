/*using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneFader : MonoBehaviour
{
    public Image fadeImage;
    public float fadeDuration = 1f;
    public string nextSceneName = "QuizScene";

    public AudioSource startBgmAudioSource;

    //private Image fadeImage;
    private bool isFading = false;

    private void Awake()
    {
        //fadeImage = GetComponent<Image>();

        if (fadeImage != null)
        {
            Color c = fadeImage.color;
            c.a = 0f;
            fadeImage.color = c;

        }
    }

    public void OnClickStart()
    {
        if (!isFading)
        {
            StartCoroutine(FadeOutAndLoad());
        }
    }

    private IEnumerator FadeOutAndLoad()
    {
        if (fadeImage == null)
        {
            SceneManager.LoadScene(nextSceneName);
            yield break;
        }

        isFading = true;
        fadeImage.raycastTarget = true;

        Color c = fadeImage.color;
        float t = 0f;

        float startVolume = 0f;
        if (startBgmAudioSource != null)
        {
            startVolume = startBgmAudioSource.volume;
        }

        while (t < fadeDuration)
        {
            t += Time.unscaledDeltaTime;
            float normalized = Mathf.Clamp01(t / fadeDuration);

            float alpha = normalized;
            fadeImage.color = new Color(c.r, c.g, c.b, alpha);

            if (startBgmAudioSource != null)
            {
                startBgmAudioSource.volume = Mathf.Lerp(startVolume, 0f, normalized);
            }

            yield return null;
        }

        if (startBgmAudioSource != null)
        {
            startBgmAudioSource.Stop();
        }

        SceneManager.LoadScene(nextSceneName);
    }
}*/
