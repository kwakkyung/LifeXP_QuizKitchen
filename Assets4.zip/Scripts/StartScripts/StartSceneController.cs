using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartSceneController : MonoBehaviour
{
    public Image fadeBlack;
    public float fadeDuration = 5f;
    public string nextSceneName = "QuizScene";
    //->
    public AudioSource startBGMSource;
    //<-
    private bool isFading = false;

    public void OnClickStart()
    {
        if (!isFading)
        {
            StartCoroutine(FadeAndLoad());
        }
    }

    private IEnumerator FadeAndLoad()
    {
        isFading = true;

        Color c = fadeBlack.color;
        float t = 0f;

        //->
        float startVolume = 0f;
        if (startBGMSource != null)
        {
            startVolume = startBGMSource.volume;
        }
        //<-


        while (t < fadeDuration)
        {
            t += Time.deltaTime;
            float alpha = Mathf.Clamp01(t / fadeDuration);

            fadeBlack.color = new Color(c.r, c.g, c.b, alpha);

            //->
            if (startBGMSource != null)
            {
                startBGMSource.volume = Mathf.Lerp(startVolume, 0f, alpha);
            }
            //-<

            yield return null;
        }

        if (startBGMSource != null)
        {
            startBGMSource.Stop();
        }

        SceneManager.LoadScene(nextSceneName);
    }
}
