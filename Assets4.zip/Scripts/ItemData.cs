using UnityEngine;

// 이 설정을 추가해야 Project 창에서 우클릭 메뉴로 이 데이터 파일을 만들 수 있습니다.
[CreateAssetMenu(fileName = "New Item Data", menuName = "Shop/Item Data")]
public class ItemData : ScriptableObject
{
    [Header("아이템 정보")]
    public string itemName = "새 아이템";
    public string itemDescription = "아이템에 대한 자세한 설명입니다.";
    public int price = 100;
    public Sprite itemIcon; // 상점에서 아이콘을 표시할 때 사용
}